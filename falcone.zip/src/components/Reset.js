export function Reset() {
  return window.location.reload();
}
