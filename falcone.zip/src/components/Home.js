export const Home = () => {
  return <div>Greek Trust Home</div>;
};
