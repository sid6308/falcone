import "./Styles.css";
export const Footer = () => {
  return (
    <div className="footer">
      <p>Coding Problem - www.geektrust.in/finding-falcone</p>
    </div>
  );
};
